new Vue({
        el: '#exercise',
        data: {
            value: ''
        }
    });